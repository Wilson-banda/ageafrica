let users = JSON.parse(localStorage.getItem("users")) || {};
let ideas = JSON.parse(localStorage.getItem("ideas")) || [];

function signup() {
    let firstName = document.getElementById("signup-firstname").value;
    let secondName = document.getElementById("signup-secondname").value;
    let email = document.getElementById("signup-email").value;
    let university = document.getElementById("signup-university").value;
    let organization = document.getElementById("signup-organization").value;
    let username = document.getElementById("signup-username").value.toLowerCase();
    let password = document.getElementById("signup-password").value;

    if (organization.toLowerCase() !== "age africa") {
        alert("Only Age Africa students can sign up!");
        return;
    }

    if (users[username]) {
        alert("Username already exists!");
        return;
    }

    users[username] = { firstName, secondName, email, university, password };
    localStorage.setItem("users", JSON.stringify(users));
    alert("Sign up successful! You can now log in.");
}

function login() {
    let username = document.getElementById("login-username").value.toLowerCase();
    let password = document.getElementById("login-password").value;

    if (users[username] && users[username].password === password) {
        sessionStorage.setItem("currentUser", username);
        document.getElementById("auth-section").style.display = "none";
        document.getElementById("discussion-section").style.display = "block";
        document.getElementById("user-display").innerText = users[username].firstName;
        displayIdeas();
    } else {
        alert("Invalid username or password!");
    }
}

function logout() {
    sessionStorage.removeItem("currentUser");
    document.getElementById("auth-section").style.display = "block";
    document.getElementById("discussion-section").style.display = "none";
}

function postIdea() {
    let username = sessionStorage.getItem("currentUser");
    let title = document.getElementById("idea-title").value;
    let text = document.getElementById("idea-text").value;
    let category = document.getElementById("idea-category").value;

    let newIdea = { username, title, text, category, comments: [] };
    ideas.push(newIdea);
    localStorage.setItem("ideas", JSON.stringify(ideas));
    displayIdeas();
}

function displayIdeas() {
    let ideasContainer = document.getElementById("ideas-container");
    ideasContainer.innerHTML = "";

    ideas.forEach((idea, index) => {
        let ideaElement = document.createElement("div");
        ideaElement.classList.add("idea");

        ideaElement.innerHTML = `
            <h4>${idea.title} - <small>[${idea.category}]</small></h4>
            <p>${idea.text}</p>
            <p><b>By: ${idea.username}</b></p>
            <button onclick="showCommentBox(${index})">Comment</button>
            <div class="comment-section" id="comment-section-${index}"></div>
        `;

        ideasContainer.appendChild(ideaElement);
        displayComments(index);
    });
}

function showCommentBox(index) {
    let commentSection = document.getElementById(`comment-section-${index}`);
    commentSection.innerHTML = `
        <input type="text" id="comment-input-${index}" placeholder="Add a comment">
        <button onclick="addComment(${index})">Submit</button>
    `;
}

function addComment(index) {
    let username = sessionStorage.getItem("currentUser");
    let commentText = document.getElementById(`comment-input-${index}`).value;

    if (!commentText) return;

    ideas[index].comments.push({ username, text: commentText });
    localStorage.setItem("ideas", JSON.stringify(ideas));
    displayComments(index);
}

function displayComments(index) {
    let commentSection = document.getElementById(`comment-section-${index}`);
    commentSection.innerHTML = "";
    
    ideas[index].comments.forEach(comment => {
        let commentElement = document.createElement("div");
        commentElement.classList.add("comment");
        commentElement.innerHTML = `<b>${comment.username}</b>: ${comment.text}`;
        commentSection.appendChild(commentElement);
    });
}
